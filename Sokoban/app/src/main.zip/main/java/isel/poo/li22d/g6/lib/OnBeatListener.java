package isel.poo.li22d.g6.lib;

/**
 *
 */
public interface OnBeatListener {
    void onBeat(long beat, long time);
}
