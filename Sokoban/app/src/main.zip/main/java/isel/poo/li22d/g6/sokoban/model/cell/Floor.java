package isel.poo.li22d.g6.sokoban.model.cell;

import isel.poo.li22d.g6.sokoban.model.Cell;

public class Floor extends Cell {
    public Floor() {
        super(FLOOR);
    }
}
