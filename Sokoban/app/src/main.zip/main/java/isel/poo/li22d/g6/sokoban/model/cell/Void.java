package isel.poo.li22d.g6.sokoban.model.cell;

import isel.poo.li22d.g6.sokoban.model.Cell;

public class Void extends Cell {
    public Void() {
        super(VOID);
    }
}
